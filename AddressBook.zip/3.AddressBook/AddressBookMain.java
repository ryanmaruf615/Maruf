import java.awt.*;
import java.awt.event.*;
import javax.swing.JOptionPane;
class AddressBook extends Frame{
	Button ad,delete,edit,show,search;
	Label wl,text1,text2,text3;
	DataAccess da;
	Font bFont = new Font("TimesRoman", Font.BOLD, 20);
	Font lFont = new Font("TimesRoman",Font.BOLD+Font.ITALIC, 50);
	Font wcFont = new Font("TimesRoman",Font.BOLD, 30);
	public AddressBook(DataAccess d){
		Frame f = new Frame("Address Book");
        da=d;
		ad=new Button("ADD");
		ad.setBounds(100,410,100,50);
		ad.setFont(bFont);
		delete=new Button("DELETE");
		delete.setBounds(250,410,100,50);
		delete.setFont(bFont);
		edit=new Button("EDIT");
		edit.setBounds(400,410,100,50);
		edit.setFont(bFont);
		show=new Button("SHOW");
		show.setBounds(170,480,100,50);
		show.setFont(bFont);
		search=new Button("SEARCH");
		search.setBounds(320,480,100,50);
		search.setFont(bFont);
		
		wl = new Label();
		wl.setText("Welcome, Time KilLer!!");
		wl.setBounds(50,85,550,55);
		wl.setFont(lFont);
		
		text1 = new Label();
		text1.setText("You can apply the Function,");
		text1.setBounds(50,190,550,75);
		text1.setFont(wcFont);
		text2 = new Label();
		text2.setText("those are given below, by");
		text2.setBounds(50,240,550,75);
		text2.setFont(wcFont);
		text3 = new Label();
		text3.setText("pressing the buttons.");
		text3.setBounds(50,290,550,75);
		text3.setFont(wcFont);
		
		f.add(ad);f.add(delete);f.add(edit);f.add(show);f.add(search);
		f.add(wl);f.add(text1);f.add(text2);f.add(text3);

		ad.addActionListener(new addButton(da));
		delete.addActionListener(new deleteButton(da));
		edit.addActionListener(new editButton(da));
		show.addActionListener(new showButton(da));
		search.addActionListener(new searchButton(da));
		
		f.setBackground(Color.LIGHT_GRAY);
		f.setLayout(null);
		f.setSize(600,600);
		f.setVisible(true);
		System.out.println("Frame created");
		
		f.addWindowListener(new WindowAdapter(){  
            public void windowClosing(WindowEvent e) {  
                System.out.println("ADDressWindow is closing");
				f.dispose();  
            }  
        });  
	}
}

public class AddressBookMain{
	public static void main(String s[]){
		DataAccess da=new DataAccess();
		loginframe a=new loginframe(da);	
	}
}

