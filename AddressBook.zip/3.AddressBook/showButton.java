import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;  
import java.io.*;
import java.util.Arrays;
import java.util.Vector;
import java.sql.*;
import java.awt.Container.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JFrame;
import javax.swing.table.*;
//import javax.swing.table.TableColumnModel;
//import javax.swing.table.DefaultTableModel;
class showButton implements ActionListener{
	DataAccess da;
	public showButton(DataAccess d){da=d;}
	public void actionPerformed(ActionEvent a)
	{
	    System.out.println("Going to SHOW");
		showframe sw= new showframe();
	}
}
class showframe extends Frame{

	public showframe() {
		DataAccess da=new DataAccess();
		String q="select * from wildkiller";
		ResultSet rs=da.getData(q);
		try
		{ 
		JTable table = new JTable(buildTableModel(rs));
		table.setRowHeight(50);
		TableColumnModel columnModel = table.getColumnModel();
        columnModel.getColumn(0).setPreferredWidth(100);
        columnModel.getColumn(1).setPreferredWidth(130);
        columnModel.getColumn(2).setPreferredWidth(250);
        columnModel.getColumn(3).setPreferredWidth(100);
		// set a Background color to the Jtable
        table.setBackground(Color.BLACK);
        // set Font To table
        table.setFont(new Font("", 1, 25));
        // set color to the JTable Font
        table.setForeground(Color.white);
		
		Frame f = new Frame("SHOW Frame");
		f.add(new JScrollPane(table));
		//f.setBackground(Color.LIGHT_GRAY);
		//f.setLayout(null);
		f.setSize(1000,600);
		f.setVisible(true);
		System.out.println("SF created");
		f.addWindowListener(new WindowAdapter(){  
            public void windowClosing(WindowEvent e) {  
                System.out.println("SF is closing");
				f.dispose();  
            }  
        });
		}
        catch(SQLException | HeadlessException ex){
            JOptionPane.showMessageDialog(null, ex);
        }
	  
	}
public static DefaultTableModel buildTableModel(ResultSet rs)
        throws SQLException {

    ResultSetMetaData metaData = rs.getMetaData();

    // names of columns
    Vector<String> columnNames = new Vector<String>();
    int columnCount = metaData.getColumnCount();
    for (int column = 1; column <= columnCount; column++) {
        columnNames.add(metaData.getColumnName(column));
    }

    // data of the table
    Vector<Vector<Object>> data = new Vector<Vector<Object>>();
    while (rs.next()) {
        Vector<Object> vector = new Vector<Object>();
        for (int columnIndex = 1; columnIndex <= columnCount; columnIndex++) {
            vector.add(rs.getObject(columnIndex));
        }
        data.add(vector);
    }
    return new DefaultTableModel(data, columnNames);

}
}