import java.awt.*;
import java.awt.event.*;
import javax.swing.JOptionPane;
import java.sql.SQLException;
import java.sql.ResultSet;
class editButton implements ActionListener{
	DataAccess da;
	public editButton(DataAccess d){da=d;}
	public void actionPerformed(ActionEvent a)
	{
	    System.out.println("Going to Edit");
		editframe ef= new editframe(da);
	}
}
class editing implements ActionListener{
	TextField tnum,tname,tmail,tadrs;
	DataAccess da;
	Frame f;
	public editing(){}
	public editing(Frame fr,DataAccess d,TextField tn,TextField tnm,TextField tm,TextField ta)
	{f=fr;da=d;tnum=tn;tname=tnm;tmail=tm;tadrs=ta;}
	public void actionPerformed(ActionEvent a)
	{
		try{editinbase();
		}
        catch(SQLException | HeadlessException ex){
            JOptionPane.showMessageDialog(null, ex);
        }
	}
	public void editinbase()throws SQLException
	{
		if(tnum.getText().equals("") || tname.getText().equals("") || tmail.getText().equals("") || tadrs.getText().equals("") )
		{
			
			JOptionPane.showMessageDialog(null, "please, fill all fields .");
			
		} //String sq="UPDATE wildkiller SET NAME='Arif',EMAIL='a@n',ADDRESS='world' where NUMBER='0167'";
		else{
			System.out.println("EDiting");
			String sq="UPDATE wildkiller SET NAME='"+tname.getText()+"',EMAIL='"+tmail.getText()+"',ADDRESS='"+tadrs.getText()+"' where NUMBER='"+tnum.getText()+"'";
            int c=da.updateDB(sq);
            da.close();
			f.dispose();
		    JOptionPane.showMessageDialog(null, "EDIT successfully");
		}
	}
}

class showing implements ActionListener{
	TextField tnum,tname,tmail,tadrs;
	DataAccess da;
	Frame f;
	ResultSet rs=null;
	String q="select * from wildkiller";
	public showing(){}
	public showing(Frame fr,DataAccess d,TextField tn,TextField tnm,TextField tm,TextField ta)
	{f=fr;da=d;tnum=tn;tname=tnm;tmail=tm;tadrs=ta;}
	public void actionPerformed(ActionEvent a)
	{
		try{showinbase();
		}
        catch(SQLException | HeadlessException ex){
            JOptionPane.showMessageDialog(null, ex);
        }
	}
	public void showinbase()throws SQLException
	{
		int a=0,b=0,c=0,d=0,x=0;
		if(!(tnum.getText()).equals("")){ a=1; } 
		if(!(tname.getText()).equals("")){ b=1; } 
		if(!(tmail.getText()).equals("")){ c=1; }
		if(!(tadrs.getText()).equals("")){ d=1; }
		if(a==1 && b==0 && c==0 && d==0)
		{
			int k=0;x=1;
			rs=da.getData(q);
			while(rs.next()){
            if( tnum.getText().equals(rs.getString("NUMBER")) )
			{
			 	tname.setText(rs.getString("NAME"));
				tmail.setText(rs.getString("EMAIL"));
				tadrs.setText(rs.getString("ADDRESS"));
		        JOptionPane.showMessageDialog(null, "Search successfully");
				k=1;
			} 
			 }
			if(k==0){JOptionPane.showMessageDialog(null, "This NUMBER isn't in the AddressBook.");}
            da.close();
		}
		if(b==1 && a==0 && c==0 && d==0)
		{
			rs=da.getData(q);int k=0;x=1;
			while(rs.next()){
            if( tname.getText().equals(rs.getString("NAME")) )
			{
			 	tnum.setText(rs.getString("NUMBER"));
				tmail.setText(rs.getString("EMAIL"));
				tadrs.setText(rs.getString("ADDRESS"));
		        JOptionPane.showMessageDialog(null, "Search successfully");
				k=1;
			}
			}
			if(k==0){JOptionPane.showMessageDialog(null, "This NAME isn't in the AddressBook.");}
            da.close();
		}
		if(c==1 && b==0 && a==0 && d==0)
		{
			rs=da.getData(q);int k=0;x=1;
			while(rs.next()){
            if( tmail.getText().equals(rs.getString("EMAIL")) )
			{
			 	tname.setText(rs.getString("NAME"));
				tnum.setText(rs.getString("NUMBER"));
				tadrs.setText(rs.getString("ADDRESS"));
		        JOptionPane.showMessageDialog(null, "Search successfully");
				k=1;
			}}
			if(k==0){JOptionPane.showMessageDialog(null, "This EMAIL isn't in the AddressBook.");}
            da.close();
		}
		if(d==1 && b==0 && c==0 && a==0)
		{
			rs=da.getData(q);int k=0;x=1;
			while(rs.next()){
            if( tadrs.getText().equals(rs.getString("ADDRESS")) )
			{
			 	tname.setText(rs.getString("NAME"));
				tmail.setText(rs.getString("EMAIL"));
				tnum.setText(rs.getString("NUMBER"));
		        JOptionPane.showMessageDialog(null, "Search successfully");
				k=1;
			}}
			if(k==0){JOptionPane.showMessageDialog(null, "This ADDRESS isn't in the AddressBook.");}
            da.close();
		}
		if(x==0)
		{JOptionPane.showMessageDialog(null, "Please fill only one field.");}
	}
}

class editframe extends Frame{
	Button ed,sh;
	DataAccess da;
	TextField tnum,tname,tmail,tadrs;
	Label lnum,lname,lmail,ladrs;
	Font bFont = new Font("TimesRoman", Font.BOLD, 20);
	Font lFont = new Font("TimesRoman", Font.BOLD, 20);
	Font tFont = new Font("TimesRoman", Font.BOLD, 20);
	public editframe(DataAccess d){
		da=d;
		Frame f = new Frame("EDIT Frame");

		ed=new Button("EDIT");
		ed.setBounds(180,400,100,50);
		ed.setFont(bFont);
		sh=new Button("SHOW");
		sh.setBounds(300,400,100,50);
		sh.setFont(bFont);
		lnum = new Label();
		lnum.setText("NUMBER");
		lnum.setBounds(50,85,90,30);
		lnum.setFont(lFont);
		lname = new Label();
		lname.setText("NAME");
		lname.setBounds(50,160,90,30);
		lname.setFont(lFont);
		lmail = new Label();
		lmail.setText("EMAIL");
		lmail.setBounds(50,235,90,30);
		lmail.setFont(lFont);
		ladrs = new Label();
		ladrs.setText("ADDRESS");
		ladrs.setBounds(50,310,100,30);
		ladrs.setFont(lFont);
		
		tnum = new TextField();
		tnum.setBounds(180,75,400,50);
		tnum.setFont(tFont);
		tname = new TextField();
		tname.setBounds(180,150,400,50);
		tname.setFont(tFont);
		tmail = new TextField();
		tmail.setBounds(180,225,400,50);
		tmail.setFont(tFont);
		tadrs = new TextField();
		tadrs.setBounds(180,300,400,50);
		tadrs.setFont(tFont);
		
		f.add(ed);f.add(sh);
		f.add(tnum);f.add(tname);f.add(tmail);f.add(tadrs);
		f.add(lnum);f.add(lname);f.add(lmail);f.add(ladrs);

		ed.addActionListener(new editing(f,da,tnum,tname,tmail,tadrs));
		sh.addActionListener(new showing(f,da,tnum,tname,tmail,tadrs));
		f.setBackground(Color.LIGHT_GRAY);
		f.setLayout(null);
		f.setSize(700,500);
		f.setVisible(true);
		System.out.println("EF created");
		
		f.addWindowListener(new WindowAdapter(){  
            public void windowClosing(WindowEvent e) {  
                System.out.println("EF is closing");
				f.dispose();  
            }  
        });  
	}
}