import java.awt.*;
import java.awt.event.*;
import javax.swing.JOptionPane;
import java.sql.ResultSet;
import java.sql.SQLException;
class addButton implements ActionListener{
	DataAccess da;
	public addButton(DataAccess d){da=d;}
	public void actionPerformed(ActionEvent a)
	{
	    System.out.println("Going to Add");
		addframe af= new addframe(da);
	}
}
class adding implements ActionListener{
	TextField tnum,tname,tmail,tadrs;
	DataAccess da;
	Frame f;
	public adding(){}
	public adding(Frame fr,DataAccess d,TextField tn,TextField tnm,TextField tm,TextField ta)
	{f=fr;da=d;tnum=tn;tname=tnm;tmail=tm;tadrs=ta;}
	public void actionPerformed(ActionEvent a)
	{
		try{addinbase();}
        catch(SQLException | HeadlessException ex){
            JOptionPane.showMessageDialog(null, ex);
        }
	}
	public void addinbase()throws SQLException
	{
		if( tnum.getText().equals("") || tname.getText().equals("") || tmail.getText().equals("") || tadrs.getText().equals("") )
		{
			
			JOptionPane.showMessageDialog(null, "please, fill all the fields..");
			
		}
		else{
			System.out.println("ADDING");
			String sq="insert into wildkiller values('"+tnum.getText()+"','"+tname.getText()+"','"+tmail.getText()+"','"+tadrs.getText()+"')";
            int c=da.updateDB(sq);
            da.close();
			f.dispose();
		    JOptionPane.showMessageDialog(null, "add successfully");
		}
	}
}
class addframe extends Frame{
	Button ad;
	DataAccess da;
	TextField tnum,tname,tmail,tadrs;
	Label lnum,lname,lmail,ladrs;
	Font bFont = new Font("TimesRoman", Font.BOLD, 20);
	Font lFont = new Font("TimesRoman", Font.BOLD, 20);
	Font tFont = new Font("TimesRoman", Font.BOLD, 20);
	public addframe(DataAccess d){
		da=d;
		Frame f = new Frame("ADD Frame");

		ad=new Button("ADD");
		ad.setBounds(180,400,100,50);
		ad.setFont(bFont);
		
		lnum = new Label();
		lnum.setText("NUMBER");
		lnum.setBounds(50,85,90,30);
		lnum.setFont(lFont);
		lname = new Label();
		lname.setText("NAME");
		lname.setBounds(50,160,90,30);
		lname.setFont(lFont);
		lmail = new Label();
		lmail.setText("EMAIL");
		lmail.setBounds(50,235,90,30);
		lmail.setFont(lFont);
		ladrs = new Label();
		ladrs.setText("ADDRESS");
		ladrs.setBounds(50,310,100,30);
		ladrs.setFont(lFont);
		
		tnum = new TextField();
		tnum.setBounds(180,75,400,50);
		tnum.setFont(tFont);
		tname = new TextField();
		tname.setBounds(180,150,400,50);
		tname.setFont(tFont);
		tmail = new TextField();
		tmail.setBounds(180,225,400,50);
		tmail.setFont(tFont);
		tadrs = new TextField();
		tadrs.setBounds(180,300,400,50);
		tadrs.setFont(tFont);
		
		f.add(ad);
		f.add(tnum);f.add(tname);f.add(tmail);f.add(tadrs);
		f.add(lnum);f.add(lname);f.add(lmail);f.add(ladrs);

		ad.addActionListener(new adding(f,da,tnum,tname,tmail,tadrs));
		
		f.setBackground(Color.LIGHT_GRAY);
		f.setLayout(null);
		f.setSize(700,500);
		f.setVisible(true);
		System.out.println("AF created");
		
		f.addWindowListener(new WindowAdapter(){  
            public void windowClosing(WindowEvent e) {  
                System.out.println("AF is closing");
				f.dispose();  
            }  
        });  
	}
}