import java.awt.*;
import java.awt.event.*;
import javax.swing.JOptionPane;
import java.sql.SQLException;
class deleteButton implements ActionListener{
	DataAccess da;
	public deleteButton(DataAccess d){da=d;}
	public void actionPerformed(ActionEvent a)
	{
	    System.out.println("Going to Delete");
		deleteframe df = new deleteframe(da);
	}
}
class deletion implements ActionListener{
	TextField tit,tpr;
	DataAccess da;
	Frame f;
	public deletion(){}
	public deletion(Frame fr,DataAccess d,TextField ti,TextField tp)
	{f=fr;da=d;tit=ti;tpr=tp;}
	public void actionPerformed(ActionEvent a)
	{
		try{deleteinbase();}
        catch(SQLException | HeadlessException ex){
            JOptionPane.showMessageDialog(null, ex);
        }
	}
	public void deleteinbase()throws SQLException
	{
		
		String s=tit.getText().toUpperCase();
		if(s.equals("NUMBER") || s.equals("NAME") || s.equals("EMAIL") || s.equals("ADDRESS"))
		{
		if(s.equals("") || tpr.getText().equals("") )
		{
			
			JOptionPane.showMessageDialog(null, "please, fill Info field..");
			
		}
		else{
			System.out.println("DELETION");
			String sq="delete from wildkiller where "+s+"='"+tpr.getText()+"'";
            System.out.println(sq);
            int c=da.updateDB(sq);
            da.close();
			if(c!=0)
			{
				f.dispose();
		    JOptionPane.showMessageDialog(null, "Deleted successfully");
			}
			else{JOptionPane.showMessageDialog(null, "Sorry, this profile isn't in the AddressBook.");}
		}
		}
		else{JOptionPane.showMessageDialog(null, "Type the Correct Info-Type..");}
	}
}
class deleteframe extends Frame{
	Button ad;
	DataAccess da;
	TextField titeam,tprop;
	Label liteam,lprop;
	Font bFont = new Font("TimesRoman", Font.BOLD, 20);
	Font lFont = new Font("TimesRoman", Font.BOLD, 35);
	Font tFont = new Font("TimesRoman", Font.BOLD, 25);
	public deleteframe(DataAccess d){
		da=d;
		Frame f = new Frame("Delete Frame");

		ad=new Button("DELETE");
		ad.setBounds(265,240,100,50);
		ad.setFont(bFont);
		
		liteam = new Label();
		liteam.setText("Info Type:");
		liteam.setBounds(20,50,150,50);
		liteam.setFont(lFont);
		lprop = new Label();
		lprop.setText("Info:");
		lprop.setBounds(20,160,135,50);
		lprop.setFont(lFont);
		
		
		titeam = new TextField();
		titeam.setBounds(205,50,120,50);
		titeam.setFont(tFont);
		tprop = new TextField();
		tprop.setBounds(205,160,400,50);
		tprop.setFont(tFont);
		
		f.add(ad);
		f.add(liteam);f.add(lprop);f.add(titeam);f.add(tprop);

		ad.addActionListener(new deletion(f,da,titeam,tprop));
		
		f.setBackground(Color.LIGHT_GRAY);
		f.setLayout(null);
		f.setSize(700,320);
		f.setVisible(true);
		System.out.println("DF created");
		
		f.addWindowListener(new WindowAdapter(){  
            public void windowClosing(WindowEvent e) {  
                System.out.println("DF is closing");
				f.dispose();  
            }  
        });  
	}
}