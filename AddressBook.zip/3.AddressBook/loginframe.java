import java.awt.*;
import java.awt.event.*;
import javax.swing.*; 

class loginbutton implements ActionListener{
	TextField tn;
	JPasswordField p;
	String un="Time KilLer";
	DataAccess da;
	Frame l;
	public loginbutton(Frame lg,DataAccess d,TextField t,JPasswordField ps)
	{l=lg;da=d;tn=t;p=ps;}
	public void actionPerformed(ActionEvent ae)
	{
	    int a=0;
		int b=0;
		char[] password = p.getPassword();
        char[] correctPass = new char[] {'1', '7', '2', '7'};
		System.out.println(tn.getText());
		System.out.println(p.getPassword());
		if(un.equals(tn.getText()))
		{a=1;}
		if(password.length==correctPass.length)
		{
			for(int i=0;i<password.length;i++)
		   {
			if(password[i]==correctPass[i])
			{b=1;}
		    else{b=0;break;}
	       } 
		}
		else{b=0;}
	    if( a==1 && b==0 ){JOptionPane.showMessageDialog(null, "Password Didn't Match!!");}
	    if( a==0 && b==1 ){JOptionPane.showMessageDialog(null, "Username Didn't Match!!");}
	    if( a==1 && b==1 )
		{
			AddressBook adrs=new AddressBook(da);
			l.dispose();
			JOptionPane.showMessageDialog(null, "Password Matched!! ^__^ ");
		}
		if( a==0 && b==0 ){JOptionPane.showMessageDialog(null, "Username and Password UnMatched!!");}
	    }
	}
	
class loginframe extends Frame{
	Frame l;
	Button login;
	TextField tuname;
	JPasswordField pf;
	Label us,pass,lad;
	DataAccess da;
	Font loginfont = new Font("TimesRoman", Font.BOLD, 40);
	Font bFont = new Font("Serif", Font.BOLD, 35);
	Font lFont = new Font("Serif", Font.BOLD, 35);
	Font tFont = new Font("Serif", Font.BOLD, 35);
	public loginframe(DataAccess d){
		l = new Frame("LOGIN");
        da=d;
		login=new Button("LOGIN");
		login.setBounds(175,370,150,60);
		login.setFont(bFont);
		
		us = new Label();
		us.setText("Username:");
		us.setBounds(20,150,180,100);
		us.setFont(lFont);
		
		lad = new Label();
		lad.setText("Log Into AddressBook!!");
		lad.setBounds(45,50,490,100);
		lad.setFont(loginfont);
		
		pass = new Label();
		pass.setText("Password:");
		pass.setBounds(20,250,180,100);
		pass.setFont(lFont);
		
		tuname = new TextField();
		tuname.setBounds(200,180,250,50);
		tuname.setFont(tFont);
		//tuname.setForeground(Color.BLUE);
		
		pf= new JPasswordField(4);
		pf.setFont(tFont);
        pf.setForeground(Color.BLUE);
		pf.setBounds(200,275,250,50);
		
		login.addActionListener(new loginbutton(l,da,tuname,pf));
		
		l.add(lad);l.add(us);l.add(pass);
		l.add(tuname);l.add(pf);l.add(login);
		
		l.setBackground(Color.LIGHT_GRAY);
		l.setLayout(null);
		l.setSize(500,500);
		l.setVisible(true);
		System.out.println("Log_Frame created");
		
		l.addWindowListener(new WindowAdapter(){  
            public void windowClosing(WindowEvent e) {  
                System.out.println("Window is closing");
				l.dispose();  
            }  
        });  
	}
}