public class ContactMain{
	public static void main(String [] args){
		Contact c1 = new Contact("Moon", "123-345-1", 25, "+88017654300", 'M');
		c1.showInfo();
	}
}