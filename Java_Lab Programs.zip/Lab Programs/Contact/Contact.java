public class Contact{
	private String personName;
	private String personId;
	private int age;
	private String mobile;
	private char gender;	
	public Contact(){
		personName = "no name"; personId ="no id";
		age = -1; mobile="no number"; gender='-';		
	}
	public Contact(String name, String id, int a, String mob, char g){
		personName = name; personId =id;
		age = a; mobile=mob; gender= g;		
	}
	public void showInfo(){
		System.out.println("Name: "+personName);
		System.out.println("Id: "+personId);
		System.out.println("Mobile: "+mobile);
		System.out.println("Age: "+age);
		System.out.println("Gender: "+gender);
		System.out.println("-------------------------------");
	}
	
	
	
}








