public class Account{	
	private String accName;
	private String accId;
	private int balance;	
	public Account(){
		accName="No name"; accId="no id"; balance = 0;
	}
	public Account(String name, String id, int amount){
		accName = name; accId= id; balance = amount;
	}
	public void showInfo(){
		System.out.println("Account Name: "+accName);
		System.out.println("Account ID: "+accId);
		System.out.println("Account balance: "+balance);
		System.out.println("----------------------------");
	}
	public void deposit(int amount){
		if(amount>0){
			balance = balance+amount;
		}else {
			System.out.println("Invalid deposit amount");
		}
			
	}
	public void withdraw(int amount){
		if(amount>0 && amount<=balance){
			balance = balance-amount;
		}else {
			System.out.println("Invalid withdraw amount");
		}			
	}
	public void transfer(int amount, Account rec){
		if(amount>0 && balance>=amount){
			withdraw(amount);
			rec.deposit(amount);
		}else{
			System.out.println("Invalid transfers");
		}
		
	}
	
}










