public class AccountMain{
	
	public static void main(String [] args){
		Account a1 = new Account("Sun", "100-1002-2", 10000);
		Account a2 = new Account("Moon", "101-1003-3", 20000);
		Account a3;
		a1.showInfo();
		a2.showInfo();
		a1.transfer(500, a2);
		a1.showInfo();
		a2.showInfo();
		
		
	}
	
}
