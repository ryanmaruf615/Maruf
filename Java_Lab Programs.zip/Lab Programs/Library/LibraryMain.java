public class LibraryMain{
	public static void main(String [] args){
		
		// Test code for String class, read very very carefully
		String s1 = "AIUB";
		String s2 = "AIUB";  // java use the concept of interning, it simply says, when strings have same
		if(s1==s2){          // content then share same memory.
			System.out.println("s1==s2 true");
		}else{
			System.out.println("s1==s2 false");
		}
		String s11 = "AIUB";
		String s22 = new String("AIUB");  // allocate new memory
		if(s11==s22){
			System.out.println("s11==s22 true");
		}else{
			System.out.println("s11==s22 false");
		}
		String s = "union"; 
		String t = "union";
		if(s.equals(t)){  // check for content equality
			System.out.println("s.equal(t) true");
		}else{
			System.out.println("s.equal(t) false");
		}
		//-------------------------
		
		Library aiub = new Library("AIUB Library", "Kuratali");		
		
		Book java = new Book("Complete Ref.", "Sun", "123-1234", "Computer Science", 10);
		Book cpp = new Book("Let us C++", "Moon", "0123-234", "Computer Science", 20);
		Book c = new Book("Introduction to C", "Jupiter", "543-14", "Computer Science", 40);
		Book algorithm = new Book("Welcome to Algorithm", "Sun Moon", "545-134", "Computer Science", 50);
		Book dm = new Book("Discrete Objects", "Rosen.", "253-124", "Computer Science", 70);
		
		aiub.addBook(java); aiub.addBook(cpp); aiub.addBook(c);
		aiub.addBook(algorithm); aiub.addBook(dm); 
		//aiub.showLibBooks(); 
		String name = "Introduction to Cpp";
		aiub.searchBookName(name);
		name = "Introduction to C";
		aiub.searchBookName(name);
		//aiub.deleteBook(algorithm);
		//aiub.showLibBooks();
	}
	
}