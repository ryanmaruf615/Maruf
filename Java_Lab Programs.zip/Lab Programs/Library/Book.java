
public class Book{	
	private String bookName;
	private String bookAuthor;
	private String bookId;
	private String bookType;
	private int bookCopy;
	
	public Book(){
		bookName= "No name"; bookAuthor = "no author"; bookId = "no id";
		bookType = "no type"; bookCopy=0;	
	}
	public Book(String bookName, String bookAuthor, String bookId,
				String bookType, int bookCopy){
		this.bookName= bookName; this.bookAuthor = bookAuthor;
		this.bookId = bookId; this.bookType = bookType; this.bookCopy = bookCopy;
	}
	public void showBookInfo(){
		System.out.println("Book Name: "+this.bookName);
		System.out.println("Book Author: "+this.bookAuthor);
		System.out.println("Book ID: "+this.bookId);
		System.out.println("Book Type: "+this.bookType);
		System.out.println("Book Copy: "+this.bookCopy);
		System.out.println("----------------------------------");		
	}
	public String getBookName(){
		return this.bookName;
	}
	
	
}








