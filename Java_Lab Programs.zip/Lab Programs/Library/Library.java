public class Library{	
	private String libName; 	private String libAddress;
	private Book [] listOfBooks; 	private int totalBook; 	
	public Library(){
		libName = "no lib name"; libAddress = "no lib address";
		totalBook = 0; 		listOfBooks = new Book[0];
	}
	public Library(String libName, String libAddress){
		this.libName = libName; this.libAddress = libAddress;		
		listOfBooks = new Book[1000]; totalBook = 0;
	}
	public void addBook(Book b){
		listOfBooks[totalBook]=b; totalBook++;		
	}
	public void showLibBooks(){
		System.out.println("Library Name: "+this.libName);
		System.out.println("Library address: "+this.libAddress);
		System.out.println("Library book info: -----");
		for(int i=0; i<totalBook; i++){
			listOfBooks[i].showBookInfo();
		}
	}
	public void searchAuthor(){
		
	}
	public void searchBookName(String bookName){
		String name;
		for(int i=0; i<totalBook; i++){
			name = listOfBooks[i].getBookName();
			if(name.equals(bookName)){
				System.out.println("Book found...");
				listOfBooks[i].showBookInfo(); return;
			}
		}
		System.out.println("Book Name not found");
	}
	public void deleteBook(Book book){
		for(int i=0; i<totalBook; i++){
			if(listOfBooks[i] == book){
				System.out.println("Book found at index: "+ i);
				listOfBooks[i] = listOfBooks[--totalBook];
				listOfBooks[totalBook] = null; return;
			}
		}
		System.out.println("Book not found");
	}
}










