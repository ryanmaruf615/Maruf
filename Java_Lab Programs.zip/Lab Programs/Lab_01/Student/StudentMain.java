public class StudentMain{
	
	public static void main(String [] args){
		
		Student s1 = new Student();
		Student s2 = new Student("Jupitar", "11-23456-2", "CS", 3.4);
		s1. showInfo(); s2.showInfo();
		s2. setName("Moon");
		s2.showInfo();
	}
}
