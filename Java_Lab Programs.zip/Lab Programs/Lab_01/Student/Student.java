public class Student{	
	private String name;
	private String id;
	private String dept;
	private double cgpa;	
	public Student(){
		name="No Name"; id="No Id"; dept="No dept"; cgpa = -1.0;
	}
	public Student(String n, String i, String d, double gpa){
		name=n; id= i; dept= d; cgpa = gpa;
	}	
	public void showInfo(){
		System.out.println("Name: "+name);
		System.out.println("ID: "+id);
		System.out.println("Dept: "+dept);
		System.out.println("CGPA: "+cgpa);
		System.out.println("-------------------------"); 
	}
	public void setName(String n){
		name = n;
	}
	public String getName(){
		return name;
	}
}